# GonkSkate integration development check

Extract into a NEW folder. Run RUN_INTEGRATION_CHECK.cmd and return the
GonkSkate-integration-results ZIP under logs/. Python 3.10+ is required.
This is a console engine check, not a new playable release.

Real THUG ground/air/rail now runs from an embeddable DLL. The check verifies
native contracts and deterministic movement/replay against the prior executable.
No game files are needed. Keep the v0.8.0 playable package for workshop testing.

Optional local THUG skeleton:
RUN_INTEGRATION_CHECK.cmd "C:\path\to\character.ske.xbx"
This imports a rig only. Meshes/animations/playable characters remain pending.
The derived rig stays local; results contain diagnostics, not character assets.

docs/THUG_EMBEDDED_RUNTIME.md contains the source-built Skate frontend helper.
That build needs local extracted Skate files, matching installed TU3 patches
(or a TU3 package) and the native build
toolchain. It links THUG into the frontend, but live player control remains pending.
docs/CHARACTER_IMPORT_PROGRESS.md explains the verified skeleton profile.
