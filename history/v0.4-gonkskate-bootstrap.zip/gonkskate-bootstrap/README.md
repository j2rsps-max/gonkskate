# GonkSkate Bootstrap

This is a Phase-0 architecture prototype for a THUG / Skate 3 mashup runtime.

The important rule is simple:

- Maps are data.
- Physics/gameplay is a selectable backend.
- Only one physics backend is authoritative at a time.

That lets us eventually support combinations such as:

- THUG map + THUG physics
- THUG map + Skate 3 physics
- Skate 3 map + THUG physics
- Skate 3 map + Skate 3 physics

This bootstrap intentionally contains **no copyrighted game assets or game code**.
It provides the host-side architecture that future importers/adapters can plug into.

## Run

```bash
cargo run -p gonkskate-app -- --map maps/test_thug.toml --physics thug
cargo run -p gonkskate-app -- --map maps/test_skate3.toml --physics skate3
```

## Planned integration strategy

### THUG
Use the existing THUG source/ports as the behavioral/source reference, then expose only the systems we actually need through a small native adapter:
- player/skater update
- collision queries
- rail/grind metadata
- camera state
- controller input
- trick/scoring state

### Skate 3
Use the current Skate 3 native recomp as the behavioral reference and integration target. The public recomp is C++/CMake/ReXGlue, so the practical path is a small C ABI adapter rather than rewriting the entire project in Rust on day one.

### Shared map representation
The runtime should eventually normalize:
- geometry
- collision
- materials
- rails/splines
- spawn points
- special skating metadata

The map layer must not know which skating backend is active.
