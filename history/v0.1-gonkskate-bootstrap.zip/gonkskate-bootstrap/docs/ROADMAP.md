# Roadmap

## Phase 0 - host architecture
- [x] Rust workspace
- [x] shared map manifest
- [x] switchable physics backend
- [x] deterministic no-render test loop
- [x] C ABI adapter design

## Phase 1 - THUG bring-up
- [ ] build/reference kisak-thug
- [ ] identify skater state/update loop
- [ ] identify collision query API
- [ ] identify rail/grind data
- [ ] wrap the minimum THUG gameplay surface behind C ABI
- [ ] make Rust host drive one THUG skater on a synthetic test map

## Phase 2 - map normalization
- [ ] inspect THUG scene/collision formats
- [ ] write THUG -> GonkMap importer
- [ ] load one real THUG level
- [ ] verify collision/rail metadata

## Phase 3 - Skate 3 research adapter
- [ ] build current Skate 3 recomp
- [ ] locate skater/board simulation calls
- [ ] locate world collision / physics boundary
- [ ] create instrumentation to record input/state traces
- [ ] define minimal native adapter

## Phase 4 - cross-play proof
- [ ] THUG physics on normalized Skate 3 test geometry
- [ ] Skate 3 physics on normalized THUG test geometry
- [ ] settings UI for map + physics selection
