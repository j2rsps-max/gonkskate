# GonkSkate v0.5 — First Windows Test

This package is cumulative. It contains the project work from v0.1 through v0.4,
plus exact copies of those earlier ZIPs in `history/`.

## What this test proves

v0.5 is an **integration-readiness test**. It verifies that your Windows PC can:

1. build the Rust workspace;
2. compile the shared C/C++ ABI headers;
3. clone the exact upstream THUG source we have been researching;
4. verify that the expected THUG physics files/functions are present;
5. compare our captured physics defaults against the upstream `physics.q`;
6. produce a single result ZIP for the next integration pass.

This version does **not yet claim to execute the full real THUG
`CSkaterCorePhysicsComponent` outside the game**. The point of this test is to
remove toolchain/source-layout uncertainty before v0.6 plugs the real component
into the adapter.

## Easiest path

1. Extract this ZIP to a normal writable folder, for example:

   `C:\Users\<you>\Documents\GonkSkate-v0.5`

   Avoid Program Files.

2. Open the extracted folder.

3. Right-click `RUN_FIRST_TEST.cmd` and choose **Run**.

4. If the prerequisite check reports missing software, read
   `INSTALL_REQUIREMENTS.md`, install the missing items, then run
   `RUN_FIRST_TEST.cmd` again.

5. When it finishes, look in:

   `logs\`

   It will create a file named similar to:

   `GonkSkate-v0.5-results-20261003-170000.zip`

6. Send that results ZIP back to ChatGPT.

## Do not add game files yet

The v0.5 test does not need THUG, THUG2, or Skate 3 retail game assets.

For later map/gameplay testing we will use files from your own legally obtained
copies, but keeping them out of this first test makes failures much easier to
diagnose.
