# What I need from you after running v0.5

## Required

Send back the generated ZIP from the `logs` folder:

`GonkSkate-v0.5-results-*.zip`

That bundle contains only the test output we intentionally generate:
- prerequisite versions/status;
- Rust build/test output;
- native ABI smoke-build output;
- THUG source validation output;
- physics-parameter comparison output.

## Also tell me

1. Did `RUN_FIRST_TEST.cmd` reach the final `TEST COMPLETE` message?
2. Did Windows Defender or another security tool block anything?
3. If a window closed unexpectedly, tell me approximately what the last visible
   line said.

## Not needed yet

Do not send:
- THUG/THUG2 game ISOs or retail assets;
- Skate 3 game files;
- passwords, keys, or account information.

## What I will likely need for the next gameplay/map stages

Later, on your own PC, we will need paths to your legally obtained game data.
The files should remain on your machine; our tooling can read/extract them
locally rather than bundling copyrighted assets into GonkSkate.
