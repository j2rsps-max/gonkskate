$ErrorActionPreference = "Stop"

$Root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$LogDir = Join-Path $Root "logs\$stamp"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

$masterLog = Join-Path $LogDir "master.log"
Start-Transcript -Path $masterLog -Force | Out-Null

$failed = $false
$failureReason = ""

try {
    Write-Host ""
    Write-Host "============================================"
    Write-Host " GonkSkate v0.5 Integration Readiness Test"
    Write-Host "============================================"
    Write-Host "Root: $Root"
    Write-Host "Logs: $LogDir"

    Write-Host ""
    Write-Host "[1/6] Toolchain preflight"
    & (Join-Path $PSScriptRoot "preflight.ps1") -LogDir $LogDir
    if ($LASTEXITCODE -ne 0) {
        throw "Prerequisite check failed. Install missing items from INSTALL_REQUIREMENTS.md, then rerun."
    }

    Write-Host ""
    Write-Host "[2/6] Rust workspace test"
    Push-Location $Root
    try {
        cargo test --workspace 2>&1 | Tee-Object -FilePath (Join-Path $LogDir "cargo-test.txt")
        if ($LASTEXITCODE -ne 0) { throw "cargo test failed" }
    } finally {
        Pop-Location
    }

    Write-Host ""
    Write-Host "[3/6] Native C/C++ ABI smoke build"
    $nativeBuild = Join-Path $Root "build\native-smoke"
    if (Test-Path $nativeBuild) { Remove-Item -Recurse -Force $nativeBuild }
    cmake -S (Join-Path $Root "native\smoke") -B $nativeBuild -A x64 2>&1 |
        Tee-Object -FilePath (Join-Path $LogDir "cmake-configure.txt")
    if ($LASTEXITCODE -ne 0) { throw "CMake configure failed" }

    cmake --build $nativeBuild --config Release 2>&1 |
        Tee-Object -FilePath (Join-Path $LogDir "cmake-build.txt")
    if ($LASTEXITCODE -ne 0) { throw "Native ABI smoke build failed" }

    $smoke = Get-ChildItem $nativeBuild -Recurse -Filter "gonkskate_abi_smoke.exe" |
        Select-Object -First 1
    if (-not $smoke) { throw "Could not find gonkskate_abi_smoke.exe" }

    & $smoke.FullName 2>&1 | Tee-Object -FilePath (Join-Path $LogDir "native-smoke-run.txt")
    if ($LASTEXITCODE -ne 0) { throw "Native ABI smoke executable failed" }

    Write-Host ""
    Write-Host "[4/6] Fetch THUG reference source"
    & (Join-Path $PSScriptRoot "bootstrap-upstream.ps1") -Root $Root -LogDir $LogDir

    Write-Host ""
    Write-Host "[5/6] Validate THUG physics source layout"
    & (Join-Path $PSScriptRoot "validate-thug-source.ps1") -Root $Root -LogDir $LogDir

    Write-Host ""
    Write-Host "[6/6] Compare captured THUG physics defaults"
    $python = Get-Command python -ErrorAction SilentlyContinue
    if ($python) {
        & python (Join-Path $Root "tools\compare_thug_params.py") $Root $LogDir 2>&1 |
            Tee-Object -FilePath (Join-Path $LogDir "thug-param-compare.txt")
    } else {
        $py = Get-Command py -ErrorAction SilentlyContinue
        if ($py) {
            & py -3 (Join-Path $Root "tools\compare_thug_params.py") $Root $LogDir 2>&1 |
                Tee-Object -FilePath (Join-Path $LogDir "thug-param-compare.txt")
        } else {
            "Python unavailable; parameter comparison skipped." |
                Set-Content (Join-Path $LogDir "thug-param-compare.txt")
        }
    }

    "PASS" | Set-Content (Join-Path $LogDir "OVERALL_RESULT.txt")
}
catch {
    $failed = $true
    $failureReason = $_.Exception.Message
    Write-Host ""
    Write-Host "TEST FAILED: $failureReason"
    "FAIL`n$failureReason" | Set-Content (Join-Path $LogDir "OVERALL_RESULT.txt")
}
finally {
    Stop-Transcript | Out-Null

    # Snapshot useful project metadata but no game assets or personal files.
    Copy-Item (Join-Path $Root "VERSION") $LogDir -ErrorAction SilentlyContinue
    Copy-Item (Join-Path $Root "native\thug_adapter\config\thug_core_physics_defaults.json") $LogDir -ErrorAction SilentlyContinue

    $resultZip = Join-Path $Root ("logs\GonkSkate-v0.5-results-" + $stamp + ".zip")
    Compress-Archive -Path (Join-Path $LogDir "*") -DestinationPath $resultZip -Force

    Write-Host ""
    Write-Host "============================================"
    if ($failed) {
        Write-Host " TEST COMPLETE - FAILURE CAPTURED"
        Write-Host " Reason: $failureReason"
    } else {
        Write-Host " TEST COMPLETE - PASS"
    }
    Write-Host "============================================"
    Write-Host ""
    Write-Host "Send this file back to ChatGPT:"
    Write-Host "  $resultZip"
    Write-Host ""
}

if ($failed) { exit 1 } else { exit 0 }
