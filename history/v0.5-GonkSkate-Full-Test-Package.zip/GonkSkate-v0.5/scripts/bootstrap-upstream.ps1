param(
    [Parameter(Mandatory=$true)]
    [string]$Root,
    [Parameter(Mandatory=$true)]
    [string]$LogDir
)

$ErrorActionPreference = "Stop"
$external = Join-Path $Root "external"
$thug = Join-Path $external "kisak-thug"
New-Item -ItemType Directory -Force -Path $external | Out-Null

if (-not (Test-Path $thug)) {
    Write-Host "Cloning kisak-thug reference source..."
    git clone --depth 1 https://github.com/SwagSoftware/kisak-thug.git $thug 2>&1 |
        Tee-Object -FilePath (Join-Path $LogDir "git-clone.txt")
} else {
    Write-Host "kisak-thug already exists; refreshing it..."
    git -C $thug fetch --depth 1 origin master 2>&1 |
        Tee-Object -FilePath (Join-Path $LogDir "git-fetch.txt")
    git -C $thug reset --hard origin/master 2>&1 |
        Tee-Object -FilePath (Join-Path $LogDir "git-reset.txt")
}

$commit = git -C $thug rev-parse HEAD
$commit | Set-Content (Join-Path $LogDir "kisak-thug-commit.txt")
Write-Host "kisak-thug commit: $commit"
