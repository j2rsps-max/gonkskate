# GonkSkate integration development check

Extract into a NEW folder. Run RUN_INTEGRATION_CHECK.cmd and return the
GonkSkate-integration-results ZIP under logs/. Python 3.10+ is required.
This is a console engine check, not a new playable release.

Real THUG ground/air/rail now runs from an embeddable DLL. The check verifies
native contracts and deterministic movement/replay against the prior executable.
No game files are needed. Keep the v0.8.0 playable package for workshop testing.

Optional local THUG skeleton:
RUN_INTEGRATION_CHECK.cmd "C:\\path\\to\\character.ske.xbx"
This command imports a rig only; use RUN_CHARACTER_CHECK.cmd for mesh previews.
The derived rig stays local; results contain diagnostics, not character assets.

NEW: run RUN_CHARACTER_CHECK.cmd for 26 asset-free rig/mesh/texture/animation/export checks.
For a matching local THUG PC skeleton and skin:
RUN_CHARACTER_CHECK.cmd "C:\\path\\to\\character.ske.xbx" "C:\\path\\to\\character.skin.xbx" --weight-profile dx9
Use --weight-profile xbox for the inspected original Xbox decoder instead.
This creates local-characters/thug-character-TIMESTAMP/character.glb and JSON.
The GLB is a rigged, untextured preview. Add a matching original texture dictionary:
RUN_CHARACTER_CHECK.cmd "C:\path\to\character.ske.xbx" "C:\path\to\character.skin.xbx" --weight-profile dx9 --textures "C:\path\to\character.tex.xbx"
This embeds the first source material pass. DXT1/DXT5 and swizzled 8/16/32-bit
images are supported; original multipass shader effects remain metadata.
Add a matching original skeletal clip:
RUN_CHARACTER_CHECK.cmd "C:\\path\\to\\character.ske.xbx" "C:\\path\\to\\character.skin.xbx" --weight-profile dx9 --animation "C:\\path\\to\\skater_Push.ska.xbx"
Select "THUG local clip" in your GLB viewer/editor's animation controls.
For compressed clips that require lookup tables, supply matching original local
--q-table and/or --t-table files (2048 bytes each). The importer reports missing
tables instead of guessing. It rejects unsupported partial/event/camera clips.
Bone counts must match; source files do not prove the correct rig identity.
Animation preview uses original samples at 60 Hz with STEP interpolation;
configure a viewer's animation resampling to retain 60 Hz if it bakes tracks.
This does not add a playable character. Retail texture compatibility, original
shader effects, gameplay animation selection and live attachment remain pending.
No game files are needed for the asset-free check.
Return the GonkSkate-character-results ZIP under logs/; derived assets stay local.

docs/THUG_EMBEDDED_RUNTIME.md contains the source-built Skate frontend helper.
That build needs local extracted Skate files, matching installed TU3 patches
(or a TU3 package) and the native build
toolchain. It links THUG into the frontend, but live player control remains pending.
docs/CHARACTER_IMPORT_PROGRESS.md explains the checked skeleton/mesh profiles.
