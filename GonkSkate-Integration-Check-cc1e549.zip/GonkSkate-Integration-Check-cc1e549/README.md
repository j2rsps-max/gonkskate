# GonkSkate integration development check

Extract into a NEW folder. Run RUN_INTEGRATION_CHECK.cmd and return the
GonkSkate-integration-results ZIP under logs/. Python 3.10+ is required.
This is a console engine check, not a new playable release.

Real THUG ground/air/rail now runs from an embeddable DLL. The check verifies
native contracts and deterministic movement/replay against the prior executable.
No game files are needed. Keep the v0.8.0 playable package for workshop testing.

Optional local THUG skeleton:
RUN_INTEGRATION_CHECK.cmd "C:\path\to\character.ske.xbx"
This command imports a rig only; use RUN_CHARACTER_CHECK.cmd for mesh previews.
The derived rig stays local; results contain diagnostics, not character assets.

NEW: run RUN_CHARACTER_CHECK.cmd for asset-free mesh/rigged-export checks.
For a matching local THUG PC skeleton and skin:
RUN_CHARACTER_CHECK.cmd "C:\path\to\character.ske.xbx" "C:\path\to\character.skin.xbx" --weight-profile dx9
Use --weight-profile xbox for the inspected original Xbox decoder instead.
This creates local-characters/thug-character-TIMESTAMP/character.glb and JSON.
The GLB is a rigged, untextured neutral-pose preview. It does not add a playable
character. Textures, animations, retail appearance and live frontend attachment
remain pending. No game files are needed for the asset-free check.
Return the GonkSkate-character-results ZIP under logs/; derived assets stay local.

docs/THUG_EMBEDDED_RUNTIME.md contains the source-built Skate frontend helper.
That build needs local extracted Skate files, matching installed TU3 patches
(or a TU3 package) and the native build
toolchain. It links THUG into the frontend, but live player control remains pending.
docs/CHARACTER_IMPORT_PROGRESS.md explains the checked skeleton/mesh profiles.
