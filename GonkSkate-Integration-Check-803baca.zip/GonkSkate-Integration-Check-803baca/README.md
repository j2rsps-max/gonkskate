# GonkSkate integration development check

Extract into a NEW folder. Run RUN_INTEGRATION_CHECK.cmd and return the
GonkSkate-integration-results ZIP under logs/. Python 3.10+ is required.
This is a console engine check, not a new playable release.
Read docs/CURRENT_CHECKPOINT.md for verified results, package selection and the
THUG asset handoff. The owner's 26 synthetic character tests already passed;
real character files and the live Skate player connection remain unvalidated.
CODEX_HANDOFF.md and CODEX_START_PROMPT.txt prepare a new local/cloud Codex chat.
For coding, clone the full repository into Z:\Games\GonkSkate\Source; this ZIP
is only a portable subset. Keep the existing THUG folder separate from Source,
Integration (this package's contents) and Playable (v0.8.0 package contents).
Use a main-only source checkout to keep historical binary packages in the
separate downloads workflow:
git clone --single-branch --branch main https://github.com/j2rsps-max/gonkskate.git "Z:\Games\GonkSkate\Source"

Real THUG ground/air/rail now runs from an embeddable DLL. The check verifies
native contracts and deterministic movement/replay against the prior executable.
No game files are needed. Keep the v0.8.0 playable package for workshop testing.

NEW: run RUN_CHARACTER_CHECK.cmd for 26 asset-free rig/mesh/texture/animation/export checks.
This needs no game files. If THUG is not installed/extracted yet, use this check.

To import a real character, double-click RUN_CHARACTER_IMPORT.cmd.
If you do not know which files to select, first run RUN_THUG_FILE_CHECK.cmd and
browse to the installed THUG folder. Return its GonkSkate-thug-files-results ZIP;
it lists only filenames/sizes and does not read or copy retail asset contents.
Use Browse to select the original skeleton and its matching mesh from your
installed/extracted THUG files. Choose their original platform (PC/DX9 or Xbox).
Textures, an animation and any needed compression tables are optional fields.
The picker requires Python's Tcl/Tk support (included in its standard installer).
Game files are not included with GonkSkate; C:\path\... in older examples was
a placeholder and must not be copied as an actual installed location.
This creates local-characters/thug-character-TIMESTAMP/character.glb and JSON.
With a matching texture dictionary it embeds the first source material pass.
DXT1/DXT5 and swizzled 8/16/32-bit images are supported; original multipass
shader effects remain metadata. For command-line use, see the documentation's
explicitly labelled examples and replace every path with an existing file.
Select "THUG local clip" in your GLB viewer/editor's animation controls.
For compressed clips that require lookup tables, supply matching original local
--q-table and/or --t-table files (2048 bytes each). The importer reports missing
tables instead of guessing. It rejects unsupported partial/event/camera clips.
Bone counts must match; source files do not prove the correct rig identity.
Animation preview uses original samples at 60 Hz with STEP interpolation;
configure a viewer's animation resampling to retain 60 Hz if it bakes tracks.
This does not add a playable character. Retail texture compatibility, original
shader effects, gameplay animation selection and live attachment remain pending.
No game files are needed for the asset-free check.
Return the GonkSkate-character-results ZIP under logs/; derived assets stay local.

docs/THUG_EMBEDDED_RUNTIME.md contains the source-built Skate frontend helper.
That build needs local extracted Skate files, matching installed TU3 patches
(or a TU3 package) and the native build
toolchain. It links THUG into the frontend, but live player control remains pending.
docs/CHARACTER_IMPORT_PROGRESS.md explains the checked skeleton/mesh profiles.
